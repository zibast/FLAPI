auth_api_project/
├── app.py
├── users.json
├── requirements.txt
└── README.md