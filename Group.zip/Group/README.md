# پروژه API احراز هویت ساده با Flask

این پروژه یک API ساده برای ثبت‌نام، ورود و مشاهده پروفایل کاربران است.

## نصب

```bash
pip install -r requirements.txt